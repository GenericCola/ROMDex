# ROMDex Agent File Tools — U23A

Read rdx/AGENT-FILE-TRANSFER.md. Node.js 22+ is required. These deterministic tools do not use AI. Supply the exact authorized task handoff and securely configure the agent environment connection. No credentials, private saves, ROM or live task data are included. The current executable CLI/schema is authoritative; do not substitute historical fixture IDs.
