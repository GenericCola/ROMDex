(function(root){
 'use strict';
 const effectsFor=(index,recordId,pointId=null,blockId=null)=>(index?.effects||[]).filter(e=>e.target.recordId===recordId&&(!pointId||e.target.pointId===pointId)&&(!blockId||e.target.blockIds.includes(blockId)));
 function describe(expr){
  if(!expr)return 'Access requirements unresolved.';
  if(expr.op==='constant')return expr.value?'Always available in this source context':'This source path is not taken';
  if(expr.op==='flag')return 'Flag '+expr.flagId+' '+expr.state;
  if(expr.op==='variable')return 'Variable '+expr.variableId+' '+({eq:'=',ne:'≠',lt:'<',lte:'≤',gt:'>',gte:'≥'})[expr.compare]+' '+expr.value;
  if(expr.op==='runtime')return (expr.check==='time'&&expr.arguments.part==='weekday'?'Weekday':expr.check)+' '+({eq:'=',ne:'≠',lt:'<',lte:'≤',gt:'>',gte:'≥'})[expr.compare]+' '+expr.value;
  if(expr.op==='unknown')return 'Unresolved: '+expr.reason;
  if(expr.op==='not')return 'NOT ('+describe(expr.arg)+')';
  return '('+expr.args.map(describe).join(expr.op==='all'?' AND ':' OR ')+')';
 }
 const hasUnknown=expr=>expr.op==='unknown'||expr.op==='not'&&hasUnknown(expr.arg)||['all','any'].includes(expr.op)&&expr.args.some(hasUnknown);
 const knownConditions=index=>(index?.displayOrder||[]).map(id=>index.conditions.find(c=>c.id===id)).filter(c=>c&&!hasUnknown(c.expression));
 function stages(index){return knownConditions(index).map(c=>({id:c.id,name:c.label,event:describe(c.expression),conditionEffect:true,uncertain:false}));}
 function indexFor(snapshot,town){return snapshot.timelines?.[town?.timelineRef]?.conditionIndex||null;}
 function blockEffects(index,recordId,pointId,blockId){return effectsFor(index,recordId,pointId,blockId).filter(e=>e.kind==='dialogue');}
 function matches(index,recordId,pointId,blockId,selection){
  if(selection==='all'||selection==='conditional')return true;
  const effects=blockEffects(index,recordId,pointId,blockId);
  if(selection==='unresolved')return !effects.length||effects.some(e=>hasUnknown(e.requires));
  return effects.some(e=>e.conditionIds.includes(selection));
 }
 root.romdexConditions=Object.freeze({effectsFor,describe,hasUnknown,knownConditions,stages,indexFor,blockEffects,matches});
})(globalThis);
